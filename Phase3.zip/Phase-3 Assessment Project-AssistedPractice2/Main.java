package Assisted.Ap21;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class Main {
    public static void main(String[] args) {
        // Create a JFrame
        final JFrame frame = new JFrame("Event Handling Demo");

        // Create a JButton
        JButton button = new JButton("Click Me!");

        // Add default event handler using an anonymous inner class
        button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Display a message dialog
                JOptionPane.showMessageDialog(frame, "Default Event Handler");
            }
        });

        // Add custom event handler using a separate class
        CustomActionListener customListener = new CustomActionListener();
        button.addActionListener(customListener);

        // Add the button to the frame
        frame.getContentPane().add(button);

        // Set frame properties
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(300, 200);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}

// Custom event handler class
class CustomActionListener implements ActionListener {
    public void actionPerformed(ActionEvent e) {
        // Display a message dialog
        JOptionPane.showMessageDialog(null, "Custom Event Handler");
    }
}

