package com.example;
public class MyBean {
    public void sayHello() {
        System.out.println("Hello, Spring Framework!");
    }
}
