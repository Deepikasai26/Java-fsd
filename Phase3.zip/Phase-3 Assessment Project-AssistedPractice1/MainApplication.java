package com.example;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class MainApplication {
    public static void main(String[] args) {
        // Create an application context
        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
        
        // Register the configuration class
        context.register(ApplicationConfig.class);
        
        // Refresh the context
        context.refresh();
        
        // Get the bean instance
        MyBean myBean = context.getBean(MyBean.class);
        
        // Use the bean
        myBean.sayHello();
        
        // Close the context
        context.close();
    }
}

