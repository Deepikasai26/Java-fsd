package demo;
import java.util.List;
import java.util.Scanner;
import java.util.ArrayList;

public class TaxCalculatorApp {
    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
			List<Property> properties = new ArrayList<>();
			List<Vehicle> vehicles = new ArrayList<>();
System.out.println("-----------------------------------");
			    System.out.println("Welcome to the Tax Calculator App");
			    System.out.println("-----------------------------------");
			    System.out.println("Please Login To Continue -");
			    String correctUsername = "sai123";
			    String correctPassword = "sai456";
			    System.out.print("Enter username: ");
			    String enteredUsername = scanner.nextLine();
			    System.out.print("Enter password: ");
			    String enteredPassword = scanner.nextLine();
			    // Check if entered credentials are correct
			    if (enteredUsername.equals(correctUsername) && enteredPassword.equals(correctPassword)) {
			        System.out.println("Login successful! Welcome");
			    } else {
			        System.out.println("Login failed. Incorrect username or password.");
			        return;
			    }


  
			while (true) {
			    System.out.println("Select an option:");
			    System.out.println("1. Property tax");
			    System.out.println("2. Vehicle tax");
			    System.out.println("3. Total Tax");
			    System.out.println("4. Exit");
			    int choice = scanner.nextInt();
			    scanner.nextLine(); // Consume the newline character

			    switch (choice) {
			        case 1:
			        	propertyLoop:
			            while (true) {
			                System.out.println("1. Add property details");
			                System.out.println("2. Calculate property tax");
			                System.out.println("3. Display all properties");
			                System.out.println("4. Back to main menu");
			                int innerchoice = scanner.nextInt();
			                scanner.nextLine();
			                switch (innerchoice) {
			                    case 1:
			                        System.out.println("Enter the property details");
			                        System.out.print("Enter BuiltupArea: ");
			                        int builtuparea = scanner.nextInt();
			                        scanner.nextLine();
			                        System.out.print("Enter base value of land: ");
			                        double basevalueofland = scanner.nextDouble();
			                        scanner.nextLine();
			                        System.out.print("Enter age of land (in years): ");
			                        int ageofland = scanner.nextInt();
			                        scanner.nextLine();
			                        System.out.print("Is it in the city? (true/false): ");
			                        boolean isincity = scanner.nextBoolean();
			                        scanner.nextLine();

			                        Property property = new Property(builtuparea, basevalueofland, isincity, ageofland);
			                        properties.add(property);
			                        break;
			                    case 2: 
			                    	System.out.println("------------------------------------------------------------------------\n");
			                        System.out.println("ID  Builtup-area  Basevalueofland  Isincity  Ageofland  Propertytax\n");
			                        System.out.println("-------------------------------------------------------------------------\n");
			                        for (int i = 0; i < properties.size(); i++) {
			                            Property prop = properties.get(i);
			                            System.out.printf("%d\t%d\t\t%.2f\t%b\t%d\t%.2f\n", i + 1, prop.getBuiltupArea(), prop.getBaseValueOfLand(), prop.isInCity(), prop.getAgeOfLand(), prop.calculatePropertyTax());
			                        }
			                        System.out.println("-------------------------------------------------------------------------\n");
			                    	System.out.print("Enter the Property ID to calculate the Tax : ");
			                        int propertyid = scanner.nextInt();
		                       
		           
			                        for (int i = 0; i < properties.size(); i++) {
			                            Property prop = properties.get(i);
			                            if(propertyid == i+1)
			                            {
			                            	System.out.printf("Property tax for property id - "+propertyid+" is " +prop.calculatePropertyTax()+"\n");
			                            	break;
			                            }
			                        }
			                        break;
			                    case 3:
			                        System.out.println("------------------------------------------------------------------------\n");
			                        System.out.println("ID  Builtup-area  Basevalueofland  Isincity  Ageofland  Propertytax\n");
			                        System.out.println("-------------------------------------------------------------------------\n");
			                        for (int i = 0; i < properties.size(); i++) {
			                            Property prop = properties.get(i);
			                            System.out.printf("%d\t%d\t\t%.2f\t%b\t%d\t%.2f\n", i + 1, prop.getBuiltupArea(), prop.getBaseValueOfLand(), prop.isInCity(), prop.getAgeOfLand(), prop.calculatePropertyTax());
			                        }
			                        System.out.println("-------------------------------------------------------------------------\n");
			                        break;
			                    case 4:
			                        break propertyLoop;
			                }
			            }
			             break;  
			        case 2:
			        	vehicleLoop:
			            while (true) {
			                System.out.println("1. Add vehicle details");
			                System.out.println("2. Calculate vehicle tax");
			                System.out.println("3. Display all vehicles");
			                System.out.println("4. Back to main menu");
			                int innerchoice = scanner.nextInt();
			                scanner.nextLine();
			                switch (innerchoice) {
			                    case 1:
			                        System.out.println("Enter the vehicle details");
			                        System.out.print("Enter registration number: ");
			                        int regnumber = scanner.nextInt();
			                        scanner.nextLine();
			                        System.out.print("Enter brand: ");
			                        String brand = scanner.nextLine();
			                        System.out.print("Enter max velocity: ");
			                        int velocity = scanner.nextInt();
			                        scanner.nextLine();
			                        System.out.print("Enter passenger count: ");
			                        int capacity = scanner.nextInt();
			                        scanner.nextLine();
			                        System.out.print("Enter vehicle type: \n1. Petrol driven\n2. Diesel driven\n3.CNG/LPg driven\n");
			                        int vehicletype = scanner.nextInt();
			                        System.out.print("Enter cost: ");
			                        double cost = scanner.nextDouble();
			                        scanner.nextLine();
			                        Vehicle vehicle = new Vehicle(regnumber, brand, cost, velocity, capacity, vehicletype);
			                        vehicles.add(vehicle);
			                        break;
			                    case 2:
			                    	System.out.println("----------------------------------------------------------------------\n");
			                        System.out.println("S.No  Regnumber  Brand   Cost       Velocity  Capacity  Vehicletax\n");
			                        System.out.println("-----------------------------------------------------------------------\n");
			                        for (int i = 0; i < vehicles.size(); i++) {
			                            Vehicle veh = vehicles.get(i);
			                            System.out.printf("%d\t%d\t%s\t %.2f\t%d\t%d\t%.2f\n", i + 1, veh.getRegNumber(), veh.getBrand(), veh.getCost(), veh.getVelocity(), veh.getCapacity(), veh.calculateVehicleTax());
			                        }
			                        System.out.println("------------------------------------------------------------------------\n");
			                    	System.out.println("Enter the Registration Number of Vehicle to Caculate Tax : ");
			                        int Regid = scanner.nextInt();
			                        for (int i = 0; i < vehicles.size(); i++) {
			                            Vehicle veh = vehicles.get(i);
			                            if(Regid == veh.getRegNumber())
			                            {
			                            	System.out.println("Vehicle Tax for Registration Number  - "+Regid+" is " +veh.calculateVehicleTax()+"\n");
			                            	break;
			                            }
			                        }
			                            	  break;
			                       
			              
			                      
			                    case 3:
			                        System.out.println("----------------------------------------------------------------------\n");
			                        System.out.println("S.No  Regnumber  Brand   Cost       Velocity  Capacity  Vehicletax\n");
			                        System.out.println("-----------------------------------------------------------------------\n");
			                        for (int i = 0; i < vehicles.size(); i++) {
			                            Vehicle veh = vehicles.get(i);
			                            System.out.printf("%d\t%d\t%s\t %.2f\t%d\t%d\t%.2f\n", i + 1, veh.getRegNumber(), veh.getBrand(), veh.getCost(), veh.getVelocity(), veh.getCapacity(), veh.calculateVehicleTax());
			                        }
			                        System.out.println("------------------------------------------------------------------------\n");
			                        
			                        break;
			                    case 4:
			                        break vehicleLoop;
			                }
			            }
			              break;
			        case 3:
			            double totalPropertyTax = 0.0;
			            for (Property prop : properties) {
			                totalPropertyTax += prop.calculatePropertyTax();
			            }

			            double totalVehicleTax = 0.0;
			            for (Vehicle veh : vehicles) {
			                totalVehicleTax += veh.calculateVehicleTax();
			            }

			            double totalTax = totalPropertyTax + totalVehicleTax;

			            System.out.println("-------------------------------------------------------------------\n");
			            System.out.println("S.No\tparticular\tquantity\ttax\n");
			            System.out.println("--------------------------------------------------\n");
			            System.out.printf("1\tproperty\t\t%d\t\t%.2f\n", properties.size(), totalPropertyTax);
			            System.out.printf("2\tvehicle\t\t%d\t\t%.2f\n", vehicles.size(), totalVehicleTax);
			            System.out.println("-------------------------------------------------------------------\n");
			            System.out.printf("Total\t\t\t%.2f\n", totalTax);
			            System.out.println("-------------------------------------------------------------------\n");
			               break;

			        case 4:
			            System.out.println("Thank you for using the Tax Calculator App!Visit Again");
			            System.exit(0);

			        default:
			            System.out.println("Invalid option. Please choose a valid option.");
			    }
			}
		}
    }

	static void calculatePropertyTax(List<Property> properties) {
        for (Property property : properties) {
            double propertyTax = property.calculatePropertyTax();
            
        }
 
    }

    static void calculateVehicleTax(List<Vehicle> vehicles) {
        for (Vehicle vehicle : vehicles) {
            double vehicleTax = vehicle.calculateVehicleTax();
            System.out.println("Vehicle Tax: " + vehicleTax);
        }
    }

    static class Property {
        private int builtuparea;
        private double basevalueofland;
        private boolean isincity;
        private int ageofland;

        public Property(int builtuparea, double basevalueofland, boolean isincity, int ageofland) {
            this.builtuparea = builtuparea;
            this.basevalueofland = basevalueofland;
            this.isincity = isincity;
            this.ageofland = ageofland;
        }

        public int getBuiltupArea() {
            return builtuparea;
        }

        public double getBaseValueOfLand() {
            return basevalueofland;
        }

        public boolean isInCity() {
            return isincity;
        }

        public int getAgeOfLand() {
            return ageofland;
        }

        public double calculatePropertyTax() {
            double tax = 0.0;
            if(isincity) {
            	tax = ((builtuparea*ageofland*basevalueofland)+(0.5*builtuparea));
            }
            else {
            	tax = (builtuparea*ageofland*basevalueofland);
            }

            return tax;
        }
    }

    static class Vehicle {
        private int regnumber;
        private String brand;
        private double cost;
        private int velocity;
        private int capacity;
        private int vehicletype;

        public Vehicle(int regnumber, String brand, double cost, int velocity, int capacity, int vehicletype) {
            this.regnumber = regnumber;
            this.brand = brand;
            this.cost = cost;
            this.velocity = velocity;
            this.capacity = capacity;
            this.vehicletype = vehicletype;
        }


		public int getRegNumber() {
            return regnumber;
        }

        public String getBrand() {
            return brand;
        }

        public double getCost() {
            return cost;
        }

        public int getVelocity() {
            return velocity;
        }

        public int getCapacity() {
            return capacity;
        }

        public int getVehicleType() {
            return vehicletype;
        }

        public double calculateVehicleTax() {
            double tax = 0.0;
            if (vehicletype == 1) {
                tax = velocity + capacity + (0.10 * cost);
            } else if (vehicletype == 2) {
                tax = velocity + capacity + (0.11 * cost);
            } else {
                tax = velocity + capacity + (0.12 * cost);
            }
           
            return tax;
        }
    }
}