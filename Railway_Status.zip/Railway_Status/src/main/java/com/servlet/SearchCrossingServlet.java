package com.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.mapping.List;

import com.dao.CrossingDAO;

/**
 * Servlet implementation class SearchCrossingServlet
 */
@WebServlet("/SearchCrossingServlet")
public class SearchCrossingServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SearchCrossingServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		request.getRequestDispatcher("/Search_Crossing.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String crossingName = request.getParameter("crossingName");
        // Add other search criteria as needed

        // Perform search based on criteria
        List searchResults = CrossingDAO.searchCrossings(crossingName);
        // Add other search criteria as needed

        // Forward to the JSP page with the search results
        request.setAttribute("crossings", searchResults);
        request.getRequestDispatcher("/Search_Crossing_result.jsp").forward(request, response);
    

	}

}
