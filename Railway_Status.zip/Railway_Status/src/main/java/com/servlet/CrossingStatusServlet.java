package com.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.CrossingDAO;
import com.ecommerce.RailwayCrossing;

/**
 * Servlet implementation class CrossingStatusServlet
 */
@WebServlet("/CrossingStatusServlet")
public class CrossingStatusServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CrossingStatusServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		 request.getRequestDispatcher("/crossing_status.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
        String crossingIdStr = request.getParameter("crossingId");

        if (crossingIdStr != null && !crossingIdStr.isEmpty()) {
            try {
                int crossingId = Integer.parseInt(crossingIdStr);

                // Retrieve crossing information from the database
                RailwayCrossing crossing = null;
				try {
					crossing = CrossingDAO.getCrossingById(crossingId);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

                if (crossing != null) {
                    // Forward to the JSP page with crossing information
                    request.setAttribute("crossing", crossing);
                    request.getRequestDispatcher("/crossing_status_result.jsp").forward(request, response);
                } else {
                    // Crossing not found, redirect back to the form with an error message
                    request.setAttribute("error", "Crossing not found!");
                    request.getRequestDispatcher("/crossing_status.jsp").forward(request, response);
                }
            } catch (NumberFormatException e) {
                // Invalid crossing ID, redirect back to the form with an error message
                request.setAttribute("error", "Invalid crossing ID format!");
                request.getRequestDispatcher("/crossing_status.jsp").forward(request, response);
            }
        } else {
            // Crossing ID not provided, redirect back to the form with an error message
            request.setAttribute("error", "Please provide a crossing ID!");
            request.getRequestDispatcher("/crossing_status.jsp").forward(request, response);
        }

	}

}
