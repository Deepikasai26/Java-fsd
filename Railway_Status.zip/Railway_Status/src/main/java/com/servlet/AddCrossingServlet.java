package com.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.CrossingDAO;
import com.ecommerce.RailwayCrossing;

/**
 * Servlet implementation class AddCrossingServlet
 */
@WebServlet("/AddCrossingServlet")
public class AddCrossingServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddCrossingServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		request.getRequestDispatcher("/add_crossing.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String crossingName = request.getParameter("crossingName");
        String crossingAddress = request.getParameter("crossingAddress");
        String crossingLandmark = request.getParameter("crossingLandmark");
        String trainSchedule = request.getParameter("trainSchedule");
        String personInCharge = request.getParameter("personInCharge");
        String crossingStatus = request.getParameter("crossingStatus");

        RailwayCrossing newCrossing = new RailwayCrossing();
        newCrossing.setName(crossingName);
        newCrossing.setAddress(crossingAddress);
        newCrossing.setLandmark(crossingLandmark);
        newCrossing.setTrainSchedule(trainSchedule);
        newCrossing.setPersonInCharge(personInCharge);
        newCrossing.setStatus(crossingStatus);

        CrossingDAO.addCrossing(newCrossing);

        request.setAttribute("addStatus", "Crossing added successfully!");
        request.getRequestDispatcher("/add_crossing.jsp").forward(request, response);

	}

}
