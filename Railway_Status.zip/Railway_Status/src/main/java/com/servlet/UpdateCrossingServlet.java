package com.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.CrossingDAO;

/**
 * Servlet implementation class UpdateCrossingServlet
 */
@WebServlet("/UpdateCrossingServlet")
public class UpdateCrossingServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateCrossingServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		request.getRequestDispatcher("/Update.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String crossingIdStr = request.getParameter("crossingId");
        String newCrossingName = request.getParameter("crossingName");
        // Add other fields as needed for updating crossing details

        if (crossingIdStr != null && !crossingIdStr.isEmpty()) {
            try {
                int crossingId = Integer.parseInt(crossingIdStr);

                // Perform update crossing details operation
                boolean updateStatus = CrossingDAO.updateCrossingDetails(crossingId, newCrossingName);
                // Add other fields as needed for updating crossing details

                if (updateStatus) {
                    // Set update status message
                    request.setAttribute("updateStatus", "Crossing details updated successfully!");
                } else {
                    // Set error message
                    request.setAttribute("updateStatus", "Error updating crossing details!");
                }
            } catch (NumberFormatException e) {
                // Invalid crossing ID, handle appropriately
                request.setAttribute("updateStatus", "Invalid crossing ID format!");
            }
        } else {
            // Crossing ID not provided, handle appropriately
            request.setAttribute("updateStatus", "Please provide a crossing ID!");
        }

        // Forward back to the update_crossing.jsp with the update status
        request.getRequestDispatcher("/Update.jsp").forward(request, response);
}
}
