package com.dao;
import com.ecommerce.RailwayCrossing;

import java.util.List;

	public class CrossingDAOImpl implements CrossingDAO {

		public void addCrossing(RailwayCrossing crossing) {
			// TODO Auto-generated method stub
			
		}

		public List<RailwayCrossing> getAllCrossings() {
			// TODO Auto-generated method stub
			return null;
		}

		public RailwayCrossing getCrossingById(int id) {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public void updateCrossing(RailwayCrossing crossing) {
			// TODO Auto-generated method stub
			
		}

		public void deleteCrossing(int id) {
			// TODO Auto-generated method stub
			
		}

}
