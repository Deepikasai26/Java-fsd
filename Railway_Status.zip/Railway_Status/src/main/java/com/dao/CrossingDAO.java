package com.dao;
import com.ecommerce.RailwayCrossing;

import java.util.List;
	public interface CrossingDAO {
	    static void addCrossing(RailwayCrossing crossing) {
			// TODO Auto-generated method stub
			
		}
	    static List<RailwayCrossing> getAllCrossings() {
			// TODO Auto-generated method stub
			return null;
		}
	    static RailwayCrossing getCrossingById(int id) {
			// TODO Auto-generated method stub
			return null;
		}
	    void updateCrossing(RailwayCrossing crossing);
	    static boolean deleteCrossing(int id) {
			// TODO Auto-generated method stub
			return false;
		}
		static org.hibernate.mapping.List searchCrossings(String crossingName) {
			// TODO Auto-generated method stub
			return null;
		}
		static boolean markCrossingAsFavourite(int crossingId) {
			// TODO Auto-generated method stub
			return false;
		}
		static boolean updateCrossingDetails(int crossingId, String newCrossingName) {
			// TODO Auto-generated method stub
			return false;
		}


}
