package com.dao;
import com.ecommerce.User;

	public interface UserDAO {
	    static void registerUser(User user) {
			// TODO Auto-generated method stub
			
		}
	    static boolean validateUser(String username, String password) {
			// TODO Auto-generated method stub
			return false;
		}

}
